function showMessage() {
  document.getElementById("message").innerText = "Thanks for clicking!";
}
